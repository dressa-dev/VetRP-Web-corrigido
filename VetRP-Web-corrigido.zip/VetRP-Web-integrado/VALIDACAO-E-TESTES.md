# VetRP Web — validação dos oito grupos de correções

Esta versão mantém o projeto `vetrp_web` como base, preserva as migrations existentes e acrescenta V8 e V9.

## Antes de executar

1. Faça um backup do banco `vetrp` pelo MySQL Workbench.
2. Não exclua tabelas nem o histórico do Flyway.
3. Se o banco já contém tabelas mas não possui `flyway_schema_history`, pare antes de iniciar: será necessário conferir o estado do banco e fazer o baseline correto, sem recriar dados.
4. Configure `DB_USER` e `DB_PASSWORD` no IntelliJ. Para o primeiro administrador, configure também `VETRP_ADMIN_EMAIL` e `VETRP_ADMIN_PASSWORD`.
5. Use JDK 21, MySQL Community 5.7+ (recomendado 8.0) e Node.js 20+.

## Correções no código desta versão

### 1. Cadastro de funcionários
- O backend devolve `cargo` junto com `perfil` para a tabela.
- CRMV, UF e especialidade são enviados e gravados para veterinários.
- A API exige CRMV e UF no cadastro de veterinário.

### 2. Prontuário
- Formulário de diagnóstico, sintomas, tratamento, prescrição e observações com ação de salvar.
- Registro fica associado ao animal e ao veterinário autenticado.
- Consultas de animais e agendamentos carregam os relacionamentos necessários para não perder o nome do tutor com `open-in-view=false`.
- Recepção não pode consultar nem gravar informações clínicas; gravação é exclusiva de veterinário.

### 3. Agendamentos
- O tipo enviado pelo formulário é calculado pela tela selecionada; exames não são enviados como consultas.
- Motivo é obrigatório para evitar registros vazios.
- Datas usam formato ISO local `yyyy-MM-dd` e horários passados são recusados no fuso `America/Sao_Paulo`.
- A disponibilidade filtra por data, tipo e veterinário ativo vinculado.
- O veterinário do horário é selecionado a partir dos cadastros ativos e fica ligado por chave estrangeira.
- V8 cria uma restrição no MySQL para impedir dois agendamentos ativos no mesmo horário; cancelamentos liberam o horário novamente.

### 4. Vacinação
- Tipos de vacina são validados no frontend e no backend conforme a espécie.
- Veterinário pode registrar vacina aplicada, data, próxima dose e observações na carteirinha.

### 5. Foto de perfil
- Foto é salva no backend e carregada da conta.
- A imagem é convertida para um recorte quadrado central e comprimido, adequado aos avatares circulares.
- Há ações para salvar e remover; o avatar é exibido no cabeçalho, menu e perfil.

### 6. Sessão
- A credencial fica em `sessionStorage` e é validada novamente ao recarregar a página na mesma aba.
- Ao sair ou quando a sessão não é válida, a credencial é removida.

### 7. Recuperação de senha
- Solicitação por e-mail, código de seis dígitos, expiração e limite de tentativas.
- A recuperação atende qualquer conta ativa (tutor ou funcionário).
- O envio depende de SMTP configurado no IntelliJ. Sem SMTP, o backend retorna indisponibilidade; não existe envio real de código.
- Os códigos ficam em memória do processo; reiniciar o backend invalida os códigos emitidos.

### 8. Permissões
- Funcionários inativos não conseguem autenticar.
- Apenas administrador cadastra/lista/ativa/desativa funcionários.
- Administrador não consegue desativar a própria conta.
- Recepção não acessa prontuários nem carteirinhas clínicas.
- Somente veterinário grava atendimento clínico e vacina aplicada.

## Migrations novas

- `V8__impedir_agendamento_ativo_duplicado.sql`
- `V9__vincular_horarios_ao_veterinario.sql`

A V9 associa horários antigos quando o texto do profissional corresponde ao nome de um veterinário ativo. Horários antigos sem correspondência não aparecem como disponíveis; libere-os novamente escolhendo o veterinário no seletor.

## Como executar

### Backend

Abra `backend` no IntelliJ como projeto Maven, selecione JDK 21, configure as variáveis de ambiente e execute `VetrpWebApplication`.

### Frontend

No terminal, dentro de `frontend`:

```powershell
npm ci
npm run dev
```

Acesse `http://127.0.0.1:5173`.

## Teste funcional obrigatório antes da apresentação

- [ ] Criar funcionário recepcionista e conferir o cargo na tabela.
- [ ] Criar veterinário e conferir CRMV, UF e especialidade na tabela.
- [ ] Entrar como veterinário, abrir animal e salvar atendimento; conferir que aparece no histórico.
- [ ] Conferir tutor responsável no prontuário.
- [ ] Liberar horário em uma data e confirmar que não aparece em outra data.
- [ ] Liberar horários para profissionais/tipos diferentes e conferir que a lista respeita a seleção.
- [ ] Tentar agendar exame e conferir que aparece como exame.
- [ ] Tentar reservar duas vezes o mesmo horário; a segunda tentativa deve ser recusada.
- [ ] Tentar agendar horário passado; deve ser recusado.
- [ ] Tentar vacina incompatível; deve ser recusada. Registrar uma vacina compatível como veterinário.
- [ ] Salvar foto, atualizar a página, sair e entrar novamente; conferir cabeçalho, menu e perfil.
- [ ] Atualizar a página logado e conferir que a sessão permanece na mesma aba.
- [ ] Configurar SMTP e testar recuperação de senha com tutor e funcionário.
- [ ] Desativar um funcionário e confirmar que ele não consegue entrar; tentar desativar a própria conta de administrador e confirmar bloqueio.

## Limite de validação desta entrega

O ambiente usado para preparar este ZIP não conseguiu baixar as dependências do Maven/npm. Portanto, as alterações foram revisadas estaticamente, mas a compilação completa e os testes integrados com o MySQL precisam ser executados no computador de desenvolvimento, onde as dependências podem ser instaladas.
