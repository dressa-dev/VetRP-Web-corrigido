# Guia rápido — VetRP Web

## Antes de iniciar
- MySQL Community Server em execução.
- JDK 21 configurado no IntelliJ IDEA.
- Node.js 20+ instalado.
- Não publique senhas, arquivos `.env` ou credenciais no GitHub.

## Banco de dados
No MySQL Workbench (não no PowerShell), confirme que o banco `vetrp` existe:

```sql
CREATE DATABASE IF NOT EXISTS vetrp CHARACTER SET utf8mb4;
```

Se você já tem dados, **não apague o banco**. O Flyway aplica as migrations pendentes (V6 a V9, conforme o histórico do seu banco) ao iniciar o backend. Faça um backup antes da primeira execução desta versão. A V8 exige MySQL 5.7+ (recomendado MySQL 8.0). A V9 vincula horários antigos quando o nome do profissional corresponde a um veterinário ativo; horários antigos sem correspondência deixam de aparecer como disponíveis e devem ser liberados novamente escolhendo o veterinário cadastrado.

## Backend pelo IntelliJ
1. Abra a pasta `backend` como projeto Maven.
2. Configure o JDK 21 em Project Structure.
3. Abra Run > Edit Configurations > Environment variables.
4. Informe `DB_USER=root` e `DB_PASSWORD=SUA_SENHA_DO_MYSQL` (se o root não tiver senha, deixe o valor vazio).
5. Para criar o primeiro administrador, informe também `VETRP_ADMIN_EMAIL=seu-email` e `VETRP_ADMIN_PASSWORD=UmaSenhaForte!2026`.
6. Execute `VetrpWebApplication`.
7. Confira no console se o Spring iniciou e se o Flyway terminou sem erro.

A API deve responder em `http://localhost:8080`. O administrador inicial só é criado se as duas variáveis `VETRP_ADMIN_EMAIL` e `VETRP_ADMIN_PASSWORD` forem informadas na primeira inicialização.

## Frontend
Abra um terminal na pasta `frontend`:

```powershell
npm install
npm run dev
```

Acesse `http://127.0.0.1:5173`.

## Recuperação de senha
O envio de código depende de SMTP. Configure as variáveis `VETRP_SMTP_HOST`, `VETRP_SMTP_PORT`, `VETRP_SMTP_USER` e `VETRP_SMTP_PASSWORD` na configuração de execução do IntelliJ. Para Gmail, use uma senha de app.

## Publicar no GitHub
Abra o terminal na pasta raiz do projeto (a que contém `backend`, `frontend` e este guia):

```powershell
git status
git add .
git commit -m "Integra funcionalidades e corrige fluxos do VetRP"
git push
```

Se a pasta ainda não estiver clonada do seu repositório, não inicialize nem sobrescreva o remoto sem antes confirmar a URL correta. Faça o push na branch de trabalho e revise o diff antes de mesclar na branch principal.
