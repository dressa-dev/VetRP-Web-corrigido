# VetRP Web — projeto integrado

Esta versão usa **este repositório como base principal**: mantém o pacote Java `br.com.vetrp.vetrp_web`, as entidades e as migrations originais do banco MySQL (V1, V2 e V3). As telas e recursos adicionais do outro projeto foram integrados aqui sem trocar a estrutura principal do banco.

## Estrutura

- `backend/`: API Java 21 + Spring Boot + Spring Security + JPA + MySQL + Flyway.
- `frontend/`: React 18 + Vite.
- `backend/src/main/resources/db/migration/`: migrations V1 a V7. Não altere migrations já aplicadas; novos ajustes devem entrar em uma migration com número maior.

## Requisitos

- JDK 21 ou superior
- Maven 3.9 ou superior (ou abrir o projeto Maven pelo IntelliJ IDEA)
- MySQL 8
- Node.js 20 ou superior

## 1. Banco de dados

Crie o banco uma única vez no MySQL Workbench ou no terminal do MySQL:

```sql
CREATE DATABASE vetrp CHARACTER SET utf8mb4;
```

Não execute esse SQL no PowerShell. O Flyway cria as tabelas e aplica as migrations V1 a V7 quando o backend inicia. Se você já tem um banco com V1, V2 e V3 aplicadas, mantenha-o: o Flyway aplica apenas as migrations ainda não aplicadas (V4 em diante).

## 2. Backend

Configure as variáveis de ambiente na configuração de execução do IntelliJ (Run > Edit Configurations > Environment variables):

```text
DB_USER=root
DB_PASSWORD=sua_senha_do_mysql
VETRP_ADMIN_EMAIL=admin@vetrp.com.br
VETRP_ADMIN_PASSWORD=TroqueEstaSenha!2026
```

A senha do administrador deve ter pelo menos 10 caracteres, letra maiúscula, minúscula, número e símbolo. Use uma senha própria; não reutilize a senha de exemplo.

Para iniciar, abra `backend/` como projeto Maven no IntelliJ e execute `VetrpWebApplication`, ou pelo terminal com Maven instalado:

```powershell
cd backend
mvn spring-boot:run
```

A API fica em `http://localhost:8080`.

### Recuperação de senha por e-mail

O envio do código exige SMTP configurado. Para Gmail, use uma senha de app, não a senha normal da conta:

```text
VETRP_SMTP_HOST=smtp.gmail.com
VETRP_SMTP_PORT=587
VETRP_SMTP_USER=seu_email@gmail.com
VETRP_SMTP_PASSWORD=sua_senha_de_app
```

Sem essas variáveis, a recuperação informa que o serviço de e-mail não está configurado; o restante do sistema continua funcionando.

## 3. Frontend

Abra outro terminal:

```powershell
cd frontend
npm install
npm run dev
```

Acesse `http://127.0.0.1:5173`.

Se a API estiver em outro endereço, ajuste `VITE_API_URL` no arquivo `frontend/.env` usando `frontend/.env.example` como referência.

## 4. Primeiro uso

1. Entre como administrador usando as variáveis `VETRP_ADMIN_EMAIL` e `VETRP_ADMIN_PASSWORD`.
2. Em **Funcionários**, cadastre recepcionistas e veterinários. Para veterinário, preencha CRMV e UF.
3. Em **Liberar horários**, cadastre data, hora, tipo de atendimento e profissional.
4. Cadastre um tutor e seus animais.
5. Agende consulta, exame ou vacinação em horários compatíveis.
6. O veterinário pode registrar atendimentos e vacinas aplicadas no prontuário/carteirinha.

## Perfis e segurança

- `TUTOR`: gerencia os próprios animais, agenda e consulta a carteirinha de vacinação dos próprios animais.
- `RECEPCAO`: atua na agenda e nos fluxos administrativos, sem acesso ao conteúdo clínico detalhado.
- `VETERINARIO`: acessa prontuários, registra atendimentos e vacinas.
- `ADMIN`: administra funcionários e acessos.

Funcionários inativos não conseguem autenticar. O administrador não pode desativar a própria conta.

## Observações importantes

- A autenticação HTTP Basic é mantida no `sessionStorage` da aba para que atualizar a página não encerre a sessão. Ao sair, a credencial é removida.
- Fotos de perfil são salvas no banco e aparecem na navegação e no perfil.
- As migrations V4 a V7 acrescentam prontuário, carteirinha digital, foto de perfil, vacinação como tipo próprio e horários separados por tipo/profissional. Não apague as migrations antigas.
- A recuperação de senha depende de uma conta SMTP válida e configurada.
- Antes de publicar na internet, configure HTTPS, credenciais/segredos seguros e restrinja CORS aos domínios oficiais.
