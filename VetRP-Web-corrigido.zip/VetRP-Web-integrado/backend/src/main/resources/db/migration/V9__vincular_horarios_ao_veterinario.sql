-- Liga os horários ao cadastro do veterinário, sem depender apenas de texto digitado.
ALTER TABLE horario
    ADD COLUMN profissional_id BIGINT NULL,
    ADD CONSTRAINT fk_horario_profissional
        FOREIGN KEY (profissional_id) REFERENCES usuario(id),
    ADD INDEX idx_horario_profissional_data
        (profissional_id, data, tipo_atendimento, liberado);

-- A chave de disponibilidade passa a usar o ID do profissional, não seu nome.
ALTER TABLE horario
    DROP INDEX uk_horario_data_hora_profissional_tipo,
    ADD UNIQUE INDEX uk_horario_data_hora_vet_tipo
        (data, hora, tipo_atendimento, profissional_id);

-- Aproveita os horários antigos cujo nome corresponde exatamente a um veterinário ativo.
UPDATE horario h
JOIN usuario u
  ON LOWER(TRIM(u.nome)) = LOWER(TRIM(h.profissional))
 AND u.perfil = 'VETERINARIO'
 AND u.ativo = TRUE
SET h.profissional_id = u.id;
