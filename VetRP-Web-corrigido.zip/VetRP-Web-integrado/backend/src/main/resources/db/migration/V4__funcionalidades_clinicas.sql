CREATE TABLE vacina_registro (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    animal_id BIGINT NOT NULL,
    vacina VARCHAR(80) NOT NULL,
    data_aplicacao DATE NOT NULL,
    proxima_dose DATE NULL,
    observacoes VARCHAR(500) NULL,
    CONSTRAINT fk_vacina_animal FOREIGN KEY (animal_id) REFERENCES animal(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE atendimento_clinico (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    animal_id BIGINT NOT NULL,
    veterinario_id BIGINT NOT NULL,
    diagnostico VARCHAR(2000) NOT NULL,
    sintomas VARCHAR(2000) NULL,
    tratamento VARCHAR(2000) NULL,
    prescricao VARCHAR(2000) NULL,
    observacoes VARCHAR(2000) NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_atendimento_animal FOREIGN KEY (animal_id) REFERENCES animal(id),
    CONSTRAINT fk_atendimento_veterinario FOREIGN KEY (veterinario_id) REFERENCES usuario(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE usuario ADD COLUMN foto_perfil LONGTEXT NULL;
