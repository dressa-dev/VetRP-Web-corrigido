-- A unicidade antiga (data, hora) impedia dois profissionais ou tipos diferentes
-- de oferecerem atendimento no mesmo horário.
UPDATE horario SET profissional = 'A definir' WHERE profissional IS NULL OR TRIM(profissional) = '';
ALTER TABLE horario MODIFY COLUMN profissional VARCHAR(120) NOT NULL;
ALTER TABLE horario DROP INDEX uk_horario_data_hora;
ALTER TABLE horario
    ADD CONSTRAINT uk_horario_data_hora_profissional_tipo
    UNIQUE (data, hora, tipo_atendimento, profissional);
