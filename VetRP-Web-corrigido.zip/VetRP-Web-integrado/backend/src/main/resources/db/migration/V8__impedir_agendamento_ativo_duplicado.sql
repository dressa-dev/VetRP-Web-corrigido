-- Garante no próprio MySQL que um horário não tenha dois agendamentos ativos.
-- Ao cancelar, a coluna gerada passa a NULL e o horário pode ser reutilizado.
-- MySQL permite múltiplos NULL em índice UNIQUE.
ALTER TABLE agendamento
    ADD COLUMN horario_agendado_id BIGINT
        GENERATED ALWAYS AS (CASE WHEN status = 'AGENDADO' THEN horario_id ELSE NULL END) STORED,
    ADD UNIQUE INDEX uk_agendamento_horario_ativo (horario_agendado_id),
    ADD INDEX idx_agendamento_horario_status (horario_id, status);
