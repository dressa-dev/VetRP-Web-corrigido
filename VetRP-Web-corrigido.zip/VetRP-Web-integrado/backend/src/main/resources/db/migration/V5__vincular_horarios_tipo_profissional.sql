ALTER TABLE horario ADD COLUMN tipo_atendimento VARCHAR(20) NOT NULL DEFAULT 'CONSULTA';
ALTER TABLE horario ADD COLUMN profissional VARCHAR(120) NULL;
UPDATE horario h JOIN agendamento a ON a.horario_id = h.id SET h.tipo_atendimento = a.tipo, h.profissional = a.profissional;
