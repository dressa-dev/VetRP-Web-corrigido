-- A API já diferencia vacinação de consulta e exame. A coluna antiga era ENUM e rejeitava VACINACAO.
ALTER TABLE agendamento
    MODIFY COLUMN tipo ENUM('CONSULTA', 'EXAME', 'VACINACAO') NOT NULL;
