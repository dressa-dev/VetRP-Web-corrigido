package br.com.vetrp.vetrp_web.repository;

import br.com.vetrp.vetrp_web.model.VacinaRegistro;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VacinaRegistroRepository extends JpaRepository<VacinaRegistro, Long> {
    List<VacinaRegistro> findByAnimalIdOrderByDataAplicacaoDesc(Long animalId);
}
