package br.com.vetrp.vetrp_web.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "atendimento_clinico")
public class AtendimentoClinico {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "animal_id", nullable = false)
    public Animal animal;
    @ManyToOne(optional = false) @JoinColumn(name = "veterinario_id", nullable = false)
    public Usuario veterinario;
    @Column(nullable = false, length = 2000) public String diagnostico;
    @Column(length = 2000) public String sintomas;
    @Column(length = 2000) public String tratamento;
    @Column(length = 2000) public String prescricao;
    @Column(length = 2000) public String observacoes;
    @Column(name = "criado_em", nullable = false) public LocalDateTime criadoEm = LocalDateTime.now();
}
