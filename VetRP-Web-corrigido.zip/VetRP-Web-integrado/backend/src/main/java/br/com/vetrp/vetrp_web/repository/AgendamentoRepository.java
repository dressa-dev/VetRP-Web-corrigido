package br.com.vetrp.vetrp_web.repository;

import br.com.vetrp.vetrp_web.model.Agendamento;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AgendamentoRepository extends JpaRepository<Agendamento, Long> {
    @EntityGraph(attributePaths = {"animal", "animal.tutor", "horario"})
    List<Agendamento> findByAnimalTutorId(Long tutorId);

    List<Agendamento> findByHorarioIdAndStatus(Long horarioId, String status);

    boolean existsByHorarioIdAndStatus(Long horarioId, String status);

    @Override
    @EntityGraph(attributePaths = {"animal", "animal.tutor", "horario"})
    List<Agendamento> findAll();
}
