package br.com.vetrp.vetrp_web.controller;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import br.com.vetrp.vetrp_web.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/auth/recovery")
public class RecoveryController {
    private final UsuarioRepository users;
    private final PasswordEncoder encoder;
    private final JavaMailSender mail;
    private final String sender;
    private final SecureRandom random = new SecureRandom();
    private final Map<String, Challenge> codes = new HashMap<>();
    private record Challenge(String hash, Instant expires, Instant issued, int attempts) {}
    public record Request(String email) {}
    public record Reset(String email, String code, String password) {}

    public RecoveryController(UsuarioRepository users, PasswordEncoder encoder, JavaMailSender mail,
            @Value("${spring.mail.username:}") String sender) {
        this.users = users; this.encoder = encoder; this.mail = mail; this.sender = sender;
    }
    private String normalize(String value) {
        if (value == null || value.length() > 254 || !value.contains("@")) throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        return value.trim().toLowerCase(Locale.ROOT);
    }
    @PostMapping("/request")
    public synchronized Map<String,String> request(@RequestBody Request input) {
        String email = normalize(input.email()); Instant now = Instant.now();
        codes.entrySet().removeIf(e -> e.getValue().expires().isBefore(now));
        if (sender.isBlank()) throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Recuperação por e-mail não configurada no servidor");
        Challenge previous = codes.get(email);
        if (previous != null && previous.issued().plusSeconds(60).isAfter(now)) return Map.of("message", "Se a conta estiver ativa, verifique seu e-mail.");
        if (codes.size() >= 1000) throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS);
        var user = users.findByEmailIgnoreCase(email);
        String code = String.format(Locale.ROOT, "%06d", random.nextInt(1_000_000));
        if (user.isPresent() && user.get().ativo) {
            try {
                SimpleMailMessage msg = new SimpleMailMessage(); msg.setFrom(sender); msg.setTo(user.get().email);
                msg.setSubject("VetRP - Recuperação de senha");
                msg.setText("Seu código VetRP é: " + code + ". Ele é válido por 10 minutos. Se não solicitou, ignore este e-mail.");
                mail.send(msg);
                codes.put(email, new Challenge(encoder.encode(code), now.plusSeconds(600), now, 0));
            } catch (org.springframework.mail.MailException ex) {
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Não foi possível enviar o e-mail de recuperação");
            }
        }
        return Map.of("message", "Se a conta estiver ativa, verifique seu e-mail.");
    }
    @PostMapping("/reset")
    @Transactional
    public synchronized Map<String,String> reset(@RequestBody Reset input) {
        String email = normalize(input.email()); String password = input.password(); Challenge c = codes.get(email);
        if (password == null || password.length() < 10 || password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72 ||
            !password.matches(".*[A-Z].*") || !password.matches(".*[a-z].*") || !password.matches(".*[0-9].*") || !password.matches(".*[^A-Za-z0-9].*"))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A senha não atende aos requisitos de segurança");
        if (c == null || c.expires().isBefore(Instant.now()) || c.attempts() >= 5) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Código inválido ou expirado");
        codes.put(email, new Challenge(c.hash(), c.expires(), c.issued(), c.attempts() + 1));
        if (input.code() == null || !input.code().matches("[0-9]{6}") || !encoder.matches(input.code(), c.hash())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Código inválido");
        var user = users.findByEmailIgnoreCase(email).filter(u -> u.ativo).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST));
        user.senhaHash = encoder.encode(password); users.save(user); codes.remove(email);
        return Map.of("message", "Senha atualizada.");
    }
}
