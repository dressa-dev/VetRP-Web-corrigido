package br.com.vetrp.vetrp_web.repository;

import br.com.vetrp.vetrp_web.model.AtendimentoClinico;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AtendimentoClinicoRepository extends JpaRepository<AtendimentoClinico, Long> {
    @EntityGraph(attributePaths = {"veterinario"})
    List<AtendimentoClinico> findByAnimalIdOrderByCriadoEmDesc(Long animalId);
}
