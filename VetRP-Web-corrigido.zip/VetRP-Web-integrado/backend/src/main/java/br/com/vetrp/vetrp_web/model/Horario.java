package br.com.vetrp.vetrp_web.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "horario", uniqueConstraints = @UniqueConstraint(columnNames = {"data", "hora", "tipo_atendimento", "profissional_id"}))
public class Horario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public LocalDate data;

    @Column(nullable = false)
    public LocalTime hora;

    @Column(nullable = false)
    public boolean liberado = true;

    @Column(name = "tipo_atendimento", nullable = false, length = 20)
    public String tipoAtendimento = "CONSULTA";

    @Column(length = 120)
    public String profissional;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "profissional_id")
    public Usuario profissionalUsuario;
}
