package br.com.vetrp.vetrp_web.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "vacina_registro")
public class VacinaRegistro {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "animal_id", nullable = false)
    public Animal animal;
    @Column(nullable = false, length = 80)
    public String vacina;
    @Column(name = "data_aplicacao", nullable = false)
    public LocalDate dataAplicacao;
    @Column(name = "proxima_dose")
    public LocalDate proximaDose;
    @Column(length = 500)
    public String observacoes;
}
