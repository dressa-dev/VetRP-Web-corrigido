package br.com.vetrp.vetrp_web.repository;

import br.com.vetrp.vetrp_web.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import br.com.vetrp.vetrp_web.model.Perfil;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmailIgnoreCase(String email);
    Optional<Usuario> findFirstByNomeIgnoreCaseAndPerfilAndAtivoTrue(String nome, Perfil perfil);
}
